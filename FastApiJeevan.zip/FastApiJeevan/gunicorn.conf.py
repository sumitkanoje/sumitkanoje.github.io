# gunicorn.conf.py
import os

# Server socket
port = os.getenv('WEBSITES_PORT', '8080')
bind = f'0.0.0.0:{port}'
backlog = int(os.getenv('GUNICORN_BACKLOG', '2048'))

# Worker processes
workers = int(os.getenv('WEB_CONCURRENCY', '4'))  # Number of worker processes to handle requests, default is 4
worker_class = 'uvicorn.workers.UvicornWorker'  # Worker class to use for handling asynchronous web requests
worker_connections = int(os.getenv('GUNICORN_WORKER_CONNECTIONS', '1000'))  # Maximum number of simultaneous clients per worker, default is 1000
timeout = int(os.getenv('GUNICORN_TIMEOUT', '300'))  # Maximum time (in seconds) a worker will wait for a request before timing out, default is 300 seconds
keepalive = int(os.getenv('GUNICORN_KEEPALIVE', '5'))  # Number of seconds to wait for the next request on a Keep-Alive connection before closing it, default is 5 seconds


# Security
limit_request_line = int(os.getenv('GUNICORN_LIMIT_REQUEST_LINE', '4094'))
limit_request_fields = int(os.getenv('GUNICORN_LIMIT_REQUEST_FIELDS', '100'))
limit_request_field_size = int(os.getenv('GUNICORN_LIMIT_REQUEST_FIELD_SIZE', '8190'))

# Server mechanics
daemon = False  # Managed by Azure, no need to daemonize

# Logging
accesslog = os.getenv('GUNICORN_ACCESSLOG', '-')
errorlog = os.getenv('GUNICORN_ERRORLOG', '-')
loglevel = os.getenv('GUNICORN_LOGLEVEL', 'info')
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'

# Process naming
proc_name = 'fastapi_app'

# # Path to the SSL certificate and key files
# certfile = "cert.pem"
# keyfile = "key.pem"
