# pytest tests/create_schema.py 
import pytest, warnings, os, logging
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.database import Base
from app import models
from app.dependencies import get_db

SQLALCHEMY_DATABASE_URL = "sqlite:///./sql_app.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

def override_validate():
    return True

# @pytest.fixture()
# def test_db():
#     Base.metadata.create_all(bind=engine)
#     yield
#     Base.metadata.drop_all(bind=engine)

#@pytest.mark.skip

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

def test_connection():
    try:
        connection = engine.connect()
        results = connection.execute('select sqlite_version()').fetchone()
        logging.info(results[0])
    finally:
        connection.close()
        engine.dispose()

@pytest.mark.skip
def test_drop_schema():
    Base.metadata.drop_all(bind=engine)

# @pytest.mark.skip
def test_init_schema():
    Base.metadata.create_all(bind=engine)

def test_insert_lot():
    response = client.post('/lots/create', json={'lot_id':2, 'lot_code':'lot jeevan 2'})
    assert response.status_code == 200

# @pytest.mark.skip
def test_list_sites():
    response = client.get("/lots/retrieve")
    assert response.status_code == 200
    # assert len(response.json()) == 3

