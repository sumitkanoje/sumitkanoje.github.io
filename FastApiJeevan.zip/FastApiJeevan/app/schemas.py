from typing import List, Optional, Dict, Any
from pydantic import BaseModel
from datetime import date, datetime, time, timedelta
import datetime as dt
from enum import Enum

class Lot(BaseModel):
    lot_id: int
    lot_code: str
    
    class Config:
        from_attributes = True