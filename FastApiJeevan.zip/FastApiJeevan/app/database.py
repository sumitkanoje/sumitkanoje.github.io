from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

SQLALCHEMY_DATABASE_URL = "sqlite:///./sql_app.db"
# SQLALCHEMY_DATABASE_URL = "postgresql://user:password@postgresserver/db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def init_db():
    import models as models
    models.Base.metadata.create_all(bind=engine)


if __name__ == '__main__':
    try:
        # connection = engine.connect()
        # results = connection.execute('select current_version()').fetchone()
        # print(results[0])
        init_db()
    finally:
        # connection.close()
        # engine.dispose()
        pass