from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Sequence #, DATETIME, Date
from sqlalchemy.sql.functions import current_timestamp, current_date, current_user
from snowflake.sqlalchemy import DATE, DATETIME, TIME
from sqlalchemy.orm import relationship, backref
import datetime as dt, os, io, time
import pandas as pd

from app.database import Base

from enum import Enum


class Lot(Base):
    """A site for a campaign application."""
    
    __tablename__ = "LOT"
    lot_id = Column('LOT_ID', Integer, primary_key=True, nullable=False, unique=True)
    lot_code = Column('LOT_CODE', String, unique=True, nullable=False)