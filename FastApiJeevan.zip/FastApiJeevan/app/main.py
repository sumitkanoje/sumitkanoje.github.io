import logging, datetime as dt
from typing import Union

from fastapi import FastAPI, Depends, HTTPException, status

from app.routers import core, lots
from app.dependencies import get_current_username

app = FastAPI(
    title="FastAPI Endpoints",
    summary="FastAPI Endpoints Summary",
    description="Description for FastAPI Endpoints"
)

# Configure logging
logging.basicConfig(level=logging.DEBUG, filename=f"app_{dt.datetime.now().strftime('%Y_%m_%d_%H_%M_%S')}.log", filemode='a', format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@app.get("/welcome")
async def read_root(username: str = Depends(get_current_username)):
    logging.info('welcome called')
    return {"Hello": "World"}

@app.get("/items/{item_id}")
async def read_item(item_id: int, q: Union[str, None] = None, username: str = Depends(get_current_username)):
    return {"item_id": item_id, "q": q}

app.include_router(core.router)
app.include_router(lots.router)