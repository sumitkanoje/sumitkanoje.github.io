from typing import Union

from fastapi import FastAPI, Depends, HTTPException, status

from app.routers import core, lots
from app.dependencies import get_current_username

app = FastAPI(
    title="FastAPI Endpoints",
    summary="FastAPI Endpoints Summary",
    description="Description for FastAPI Endpoints"
)

@app.get("/welcome")
async def read_root(username: str = Depends(get_current_username)):
    return {"Hello": "World"}

@app.get("/items/{item_id}")
async def read_item(item_id: int, q: Union[str, None] = None, username: str = Depends(get_current_username)):
    return {"item_id": item_id, "q": q}

app.include_router(core.router)
app.include_router(lots.router)