from fastapi import APIRouter, Depends
from app.dependencies import get_current_username

router = APIRouter(
    prefix='/core',
    tags=['Core Endpoints']
    # dependencies=[Depends(validate)]
)

@router.get('/status')
async def core_status(username: str = Depends(get_current_username)):
    return {'status': 'Okay'}