from fastapi import APIRouter, Depends
from app.dependencies import get_db
from sqlalchemy.orm import Session
from app import schemas, models

router = APIRouter(
    prefix='/lots',
    tags=['Lots Endpoints']
)

@router.post('/create', response_model=schemas.Lot)
async def core_endpoint(lot:schemas.Lot, db: Session = Depends(get_db)):
    db_lot = models.Lot(
        lot_id=lot.lot_id,
        lot_code=lot.lot_code
    )
    db.add(db_lot)
    db.commit()
    return db_lot

@router.get('/retrieve', response_model=list[schemas.Lot])
async def core_endpoint(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return db.query(models.Lot).offset(skip).limit(limit).all()