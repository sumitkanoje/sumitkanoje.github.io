import secrets
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi import Depends, HTTPException, status
from app.database import SessionLocal, engine


security = HTTPBasic(
    scheme_name="Username & password Authentication",
    description="Autheticate using your username and password to access the API Endpoints"
)

def get_current_username(credentials: HTTPBasicCredentials = Depends(security)):
    print(f'Authorisation: username: {credentials.username}, pass: {credentials.password}')
    correct_username = secrets.compare_digest(credentials.username, "user")
    correct_password = secrets.compare_digest(credentials.password, "password")
    if not (correct_username and correct_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            # headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username

# Dependency
async def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()