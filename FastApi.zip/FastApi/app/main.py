from typing import Union

import secrets
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials

app = FastAPI(
    title="FastAPI Endpoints",
    summary="FastAPI Endpoints Summary",
    description="Description for FastAPI Endpoints"
)

security = HTTPBasic(
    scheme_name="Username & password Authentication",
    description="Autheticate using your username and password to access the API Endpoints"
)

def get_current_username(credentials: HTTPBasicCredentials = Depends(security)):
    print(f'Authorisation: username: {credentials.username}, pass: {credentials.password}')
    correct_username = secrets.compare_digest(credentials.username, "user")
    correct_password = secrets.compare_digest(credentials.password, "password")
    if not (correct_username and correct_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username

@app.get("/welcome")
def read_root(username: str = Depends(get_current_username)):
    return {"Hello": "World"}


@app.get("/items/{item_id}")
def read_item(item_id: int, q: Union[str, None] = None, username: str = Depends(get_current_username)):
    return {"item_id": item_id, "q": q}